export class CreatePostDto {
  title: string;
  content: string;
  imageUrl?: string; // ✅ imageUrl ko undefined ya empty string ho sakta hai
}
