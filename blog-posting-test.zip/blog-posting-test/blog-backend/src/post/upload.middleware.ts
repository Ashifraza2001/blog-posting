import { Injectable, NestMiddleware } from '@nestjs/common';
import * as multer from 'multer';
import * as AWS from 'aws-sdk';
import * as multerS3 from 'multer-s3';
import { extname } from 'path';
import * as dotenv from 'dotenv';
import { Multer } from 'multer'; // ✅ Multer ka type import karna

dotenv.config(); // ✅ ENV variables load karne ke liye

const isAwsUpload = process.env.AWS_UPLOAD === 'true'; // ✅ AWS ya Local decide karne ke liye

// ✅ AWS S3 Configuration
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: process.env.AWS_SECRET_KEY,
  region: process.env.AWS_REGION,
});

// ✅ Multer Storage Select Karega AWS ya Local
const storage = isAwsUpload
  ? multerS3({
      s3: s3,
      bucket: process.env.AWS_BUCKET_NAME,
      metadata: (req, file, cb) => {
        cb(null, { fieldName: file.fieldname });
      },
      key: (req, file, cb) => {
        const uniqueName = `${Date.now()}-${file.originalname}`;
        cb(null, uniqueName);
      },
    })
  : multer.diskStorage({
      destination: './uploads/', // ✅ Local folder
      filename: (req, file, cb) => {
        const uniqueName = `${Date.now()}-${file.originalname}`;
        cb(null, uniqueName);
      },
    });

const upload = multer({ storage });

@Injectable()
export class UploadMiddleware implements NestMiddleware {
  use(req: any, res: any, next: () => void) {
    upload.single('image')(req, res, (err: any) => { // ✅ Multer error handling properly define karo
      if (err) {
        return res.status(400).json({ message: 'File upload failed' });
      }
      next();
    });
  }
}
