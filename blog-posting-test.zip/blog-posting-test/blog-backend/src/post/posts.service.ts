import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreatePostDto } from './dto/create-post.dto';
import { Post, PostDocument } from './schemas/post.schema';

@Injectable()
export class PostsService {
  constructor(@InjectModel(Post.name) private postModel: Model<PostDocument>) {}

  // ✅ Create a new post
  async create(createPostDto: CreatePostDto, userId: string): Promise<Post> {
    const newPost = new this.postModel({ ...createPostDto, author: userId });
    return await newPost.save();
  }

  // ✅ Get all posts
  async findAll(): Promise<Post[]> {
    return await this.postModel.find().populate('author', 'name email').exec();
  }

  // ✅ Get a single post by ID
  async findOne(id: string): Promise<Post> {
    const post = await this.postModel.findById(id).populate('author', 'name email').exec();
    if (!post) throw new NotFoundException('Post not found');
    return post;
  }

  // ✅ Update a post (only if user is owner)
  async update(id: string, updateData: Partial<CreatePostDto>, userId: string): Promise<Post> {
    const post = await this.postModel.findById(id);
    if (!post) throw new NotFoundException('Post not found');
    if (post.author.toString() !== userId) throw new ForbiddenException('Unauthorized to update this post');

    Object.assign(post, updateData);
    return await post.save();
  }

  // ✅ Delete a post (only if user is owner)
  async delete(id: string, userId: string): Promise<{ message: string }> {
    const post = await this.postModel.findById(id);
    if (!post) throw new NotFoundException('Post not found');
    if (post.author.toString() !== userId) throw new ForbiddenException('Unauthorized to delete this post');

    await this.postModel.findByIdAndDelete(id);
    return { message: 'Post deleted successfully' };
  }
}
