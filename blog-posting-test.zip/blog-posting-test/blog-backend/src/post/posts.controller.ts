import { Controller, Post, Get, Put, Delete, Body, Param, UseGuards, Request, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { PostsService } from './posts.service';
import { CreatePostDto } from './dto/create-post.dto';
import { AuthGuard } from '@nestjs/passport';

const isAwsUpload = process.env.AWS_UPLOAD === 'true';

@Controller('posts')
export class PostsController {
  constructor(private readonly postsService: PostsService) {}

  @UseGuards(AuthGuard('jwt'))
  @Post()
  @UseInterceptors(FileInterceptor('image'))
  async createPost(
    @Body() createPostDto: CreatePostDto,
    @Request() req,
    @UploadedFile() file: Express.Multer.File,
  ) {
    let imageUrl: string | undefined;
    
    if (file) {
      imageUrl = file.path; // ✅ Image ka URL local ya S3 se set karna
    }

    const userId = req.user.id; // JWT se user ID
    createPostDto.imageUrl = imageUrl; // ✅ imageUrl ko assign karo

    return await this.postsService.create(createPostDto, userId);
  }


  @Get()
  findAll() {
    return this.postsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.postsService.findOne(id);
  }

  @UseGuards(AuthGuard('jwt'))
  @Put(':id')
  update(@Param('id') id: string, @Body() updateData: Partial<CreatePostDto>, @Request() req) {
    return this.postsService.update(id, updateData, req.user.sub);
  }

  @UseGuards(AuthGuard('jwt'))
  @Delete(':id')
  remove(@Param('id') id: string, @Request() req) {
    return this.postsService.delete(id, req.user.sub);
  }
}
