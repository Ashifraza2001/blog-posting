export default () => ({
    port: process.env.PORT || 3000,
    jwtSecret: process.env.JWT_SECRET || 'your-secret-key',
    googleClientId: process.env.GOOGLE_CLIENT_ID,
    googleClientSecret: process.env.GOOGLE_CLIENT_SECRET,
    facebookClientId: process.env.FACEBOOK_CLIENT_ID,
    facebookClientSecret: process.env.FACEBOOK_CLIENT_SECRET,
    MONGO_URI:process.env.MONGO_URI,
    AWS_UPLOAD:process.env.AWS_UPLOAD,
    AWS_ACCESS_KEY:process.env.AWS_ACCESS_KEY,
    AWS_SECRET_KEY:process.env.AWS_SECRET_KEY,
    AWS_BUCKET_NAME:process.env.AWS_BUCKET_NAME,
    AWS_REGION:process.env.AWS_REGION
  });
  